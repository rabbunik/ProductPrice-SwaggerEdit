package com.marlabs.caylax.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
	private String id;
	@JsonFormat(pattern="yyyy-MM-DD",shape=Shape.STRING)
	private String startDate;
	@JsonFormat(pattern="yyyy-MM-DD",shape=Shape.STRING)
	private String endDate;
	private String productSpecificId;

}
