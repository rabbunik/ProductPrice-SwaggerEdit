package com.marlabs.caylax.service;

import org.springframework.stereotype.Service;

import com.marlabs.caylax.entity.Price;
import com.marlabs.caylax.entity.Product;

@Service
public class ProductService {

	public Product productDetails(Product pp) {
		// TODO Auto-generated method stub
		pp.setId("50d203d820b9");
	    pp.setStartDate("2022-11-18");
		pp.setEndDate("2021-12-22");
		pp.setProductSpecificId("TVBPSU50HS");
	
		return pp;
	
	}

	public Price priceDetails(Price pr) {
		// TODO Auto-generated method stub
		
		pr.setBaseAmount(30.00f);
		pr.setBasePoints(3000L);
		pr.setTaxAmount(0.00f);
		pr.setTotalAmount(28.50f);
		pr.setDiscounAmount(-1.50f);
		return pr;
	}

}
