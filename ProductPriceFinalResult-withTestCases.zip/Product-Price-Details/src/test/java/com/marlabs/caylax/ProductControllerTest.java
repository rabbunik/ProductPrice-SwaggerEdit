package com.marlabs.caylax;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.marlabs.caylax.controller.ProductController;
import com.marlabs.caylax.entity.Price;
import com.marlabs.caylax.entity.Product;
import com.marlabs.caylax.service.ProductService;

@WebMvcTest(value=ProductController.class)
public class ProductControllerTest {
	@MockBean
	private ProductService service;
	@Autowired
	private MockMvc mvc;
	@Test
public void productDetailsTest() throws Exception{

	Product pp1=new Product("50d203d820b9","2022-11-18","2021-12-22","TVBPSU50HS");
	when(service.productDetails(ArgumentMatchers.any())).thenReturn(pp1);
	ObjectMapper mapper=new ObjectMapper();
	String productjson=mapper.writeValueAsString(pp1);
	MockHttpServletRequestBuilder builder=MockMvcRequestBuilders.post("/product").contentType(MediaType.APPLICATION_JSON).content(productjson);
	ResultActions actions=mvc.perform(builder);
	MvcResult result=actions.andReturn();
	MockHttpServletResponse response=result.getResponse();
	int status=response.getStatus();
	assertEquals(200,status);
}
	
	public void priceDetailsTest() throws Exception{

		Price pr2=new Price(28.50f,30.00f,3000L,0.00f,-1.50f);
		when(service.priceDetails(ArgumentMatchers.any())).thenReturn(pr2);
		ObjectMapper mapper=new ObjectMapper();
		String pricetjson=mapper.writeValueAsString(pr2);
		MockHttpServletRequestBuilder builder=MockMvcRequestBuilders.post("/product").contentType(MediaType.APPLICATION_JSON).content(pricetjson);
		ResultActions actions=mvc.perform(builder);
		MvcResult result=actions.andReturn();
		MockHttpServletResponse response=result.getResponse();
		int status=response.getStatus();
		assertEquals(200,status);
	}

	
	
}
