package com.marlabs.caylax.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Price {
	private float totalAmount;
	private float baseAmount;
	private Long basePoints;
	private float taxAmount;
	private float discounAmount;

}
