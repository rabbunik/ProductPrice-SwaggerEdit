package com.marlabs.caylax.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.marlabs.caylax.entity.Price;
import com.marlabs.caylax.entity.Product;
import com.marlabs.caylax.service.ProductService;

@RestController
public class ProductController {
@Autowired
private ProductService service;
@GetMapping("/api/product")
public String details(@RequestParam(value="pid",
required=false, defaultValue="50d203d820b9") String id,HttpServletRequest request,HttpServletResponse response)throws Exception {
	if(id.equals("50d203d820b9")) {
		response.sendRedirect("/product");
		
	}
	return "The url redirected successfully";
}

@PostMapping("/product")
public Product productDetails(@RequestBody Product pp, HttpServletRequest request,HttpServletResponse response) throws Exception{
	RequestDispatcher rd=request.getRequestDispatcher("/product/quote");
	rd.include(request, response);
	return service.productDetails(pp);
}
@PostMapping("/product/quote")
public Price priceDetails(@RequestBody Price pr) {
	return service.priceDetails(pr);
}
	
}
